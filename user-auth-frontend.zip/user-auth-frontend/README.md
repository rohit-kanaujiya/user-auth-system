# React Frontend for User Auth System

This is a simple React frontend that connects with the Node.js backend for user authentication.

## Features

- Register and login using JWT-based backend
- Store token in localStorage
- Access protected dashboard using JWT

## Setup Instructions

1. Extract the folder
2. Run `npm install` to install dependencies
3. Run `npm start` to start the React app

Make sure the backend is running on `http://localhost:5000`

## Pages

- `/` → Register
- `/login` → Login
- `/dashboard` → Protected Dashboard